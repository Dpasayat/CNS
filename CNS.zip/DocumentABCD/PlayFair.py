import string

class PlayfairSquare:
    def __init__(self, key_word):
        key_word = key_word.upper().replace('J', 'I')
        letters = []
  
        for ch in key_word:
            if ch in string.ascii_uppercase and ch not in letters:
                letters.append(ch)
        
        for ch in string.ascii_uppercase:
            if ch == 'J':
                continue  
            if ch not in letters:
                letters.append(ch)
        
        self.grid = []
        for row_start in range(0, 25, 5):
            row = letters[row_start : row_start + 5]
            self.grid.append(row)
        
        self.position = {}
        for i in range(5):
            for j in range(5):
                self.position[self.grid[i][j]] = (i, j)

    def find_letter(self, ch):
        return self.position[ch] 

    def print_square(self):
        for row in self.grid:
            print(" ".join(row))
        print()  

def prepare_text_for_encryption(text):
    text = text.upper().replace('J', 'I')
    letters = [ch for ch in text if ch in string.ascii_uppercase]
    
    pairs = []
    i = 0
    while i < len(letters):
        a = letters[i]
        b = ''
        if i + 1 < len(letters):
            b = letters[i + 1]
        
        if b == '' or a == b:
            pairs.append(a + 'X')
            i += 1
        else:
            pairs.append(a + b)
            i += 2
    
    return pairs

def prepare_text_for_decryption(text):
    text = text.upper().replace('J', 'I')
    letters = [ch for ch in text if ch in string.ascii_uppercase]
    return [letters[i : i+2] for i in range(0, len(letters), 2)]

def encrypt_pair(pair, square):
    a, b = pair[0], pair[1]
    row_a, col_a = square.find_letter(a)
    row_b, col_b = square.find_letter(b)
    
    if row_a == row_b:
        new_a = square.grid[row_a][(col_a + 1) % 5]
        new_b = square.grid[row_b][(col_b + 1) % 5]
    elif col_a == col_b:
        new_a = square.grid[(row_a + 1) % 5][col_a]
        new_b = square.grid[(row_b + 1) % 5][col_b]
    else:
        new_a = square.grid[row_a][col_b]
        new_b = square.grid[row_b][col_a]
    
    return new_a + new_b

def decrypt_pair(pair, square):
    a, b = pair[0], pair[1]
    row_a, col_a = square.find_letter(a)
    row_b, col_b = square.find_letter(b)
    
    if row_a == row_b:
        new_a = square.grid[row_a][(col_a - 1) % 5]
        new_b = square.grid[row_b][(col_b - 1) % 5]
    elif col_a == col_b:
        new_a = square.grid[(row_a - 1) % 5][col_a]
        new_b = square.grid[(row_b - 1) % 5][col_b]
    else:
        new_a = square.grid[row_a][col_b]
        new_b = square.grid[row_b][col_a]
    
    return new_a + new_b

def encrypt_message(plain_text, key_word):
    square = PlayfairSquare(key_word)
    pairs = prepare_text_for_encryption(plain_text)
    cipher_text = ""
    for p in pairs:
        cipher_text += encrypt_pair(p, square)
    
    return cipher_text

def decrypt_message(cipher_text, key_word):
    square = PlayfairSquare(key_word)
    pairs = prepare_text_for_decryption(cipher_text)
    plain_text = ""
    for p in pairs:
        plain_text += decrypt_pair(p, square)
    
    return plain_text

if __name__ == "__main__":
    print("🔒 Playfair Cipher (Kid-Friendly)") 
    print("  1) Enter a secret key word (e.g. SECRET)")
    key = input("Key word: ").strip()
    
    print("\nDo you want to:")
    print("  E) Encrypt a secret message")
    print("  D) Decrypt a coded message")
    choice = input("Type E or D: ").strip().upper()
    print()
    
    if choice == 'E':
        plain = input("Type your message to encrypt: ")
        secret = encrypt_message(plain, key)
        print("\nHere is your encrypted text:")
        print("  " + secret)
    elif choice == 'D':
        coded = input("Type your message to decrypt: ")
        revealed = decrypt_message(coded, key)
        print("\nHere is your decrypted text (may have extra X’s):")
        print("  " + revealed)
    else:
        print("Oops! You must type E or D. Try again.")