def letter_to_number(letter):
    return ord(letter) - ord('A')

def number_to_letter(number):
    return chr(number + ord('A'))

def encrypt(plaintext, key):
    ciphertext = ""          
    key_index = 0            
    key_length = len(key)    

    for char in plaintext:
        if char.isalpha():
            shift = letter_to_number(key[key_index])
            plain_num = letter_to_number(char)
            encrypted_num = (plain_num + shift) % 26
            ciphertext += number_to_letter(encrypted_num)
            key_index = (key_index + 1) % key_length
        else:
            ciphertext += char

    return ciphertext

def decrypt(ciphertext, key):
    plaintext = ""           
    key_index = 0            
    key_length = len(key)

    for char in ciphertext:
        if char.isalpha():
            shift = letter_to_number(key[key_index])
            cipher_num = letter_to_number(char)
            decrypted_num = (cipher_num - shift) % 26
            plaintext += number_to_letter(decrypted_num)
            key_index = (key_index + 1) % key_length
        else:
            plaintext += char

    return plaintext

print("Welcome to the Vigenère Cipher Program!")
print("You can encrypt or decrypt a message using a secret key.")
print()

choice = input("Type E to encrypt, or D to decrypt: ").strip().upper()

message = input("Enter your message (letters and spaces only): ").strip().upper()

key = input("Enter your secret key (letters only): ").strip().upper()

print() 

if choice == "E":
    encrypted_message = encrypt(message, key)
    print("Your encrypted message is:")
    print(encrypted_message)

elif choice == "D":
    decrypted_message = decrypt(message, key)
    print("Your decrypted message is:")
    print(decrypted_message)

else:
    print("Oops! You didn’t type E or D. Please run the program again and choose E or D.")